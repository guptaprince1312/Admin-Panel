// src/components/AdminPanel.js
import React, { useState } from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import TransactionTable from './TransactionTable';

const AdminPanel = () => {
  const [transactions, setTransactions] = useState([
    { id: 1, amount: 100, customer: 'John Doe', status: 'approved', date: '2024-01-25' },
    { id: 2, amount: 150, customer: 'Jane Smith', status: 'pending', date: '2024-01-26' },
    { id: 3, amount: 200, customer: 'Ram', status: 'approved', date: '2024-01-27' },
    { id: 4, amount: 250, customer: 'Shyam', status: 'rejected', date: '2024-01-28' },
    { id: 5, amount: 300, customer: 'Sita', status: 'pending', date: '2024-01-29' },

    // Add more sample data
  ]);

  const [filters, setFilters] = useState({
    id: '',
    amount: '',
    customer: '',
    branch: '',
    type: '',
    status: '',
    startDate: null,
    endDate: null,
  });

  const handleDelete = (id) => {
    const updatedTransactions = transactions.filter((transaction) => transaction.id !== id);
    setTransactions(updatedTransactions);
  };

  const handleSearch = (searchFilters) => {
    setFilters({ ...filters, ...searchFilters });
  };

  const handleDateFilter = (dateFilters) => {
    setFilters({ ...filters, ...dateFilters });
  };

  const handleSort = (direction) => {
    // You can add sorting logic here if needed
    console.log('Sorting direction:', direction);
  };

  const handleFilterChange = (filterChange) => {
    setFilters({ ...filters, ...filterChange });
  };

  return (
    <Container>
      <Row>
        <Col>
          <h1>Admin Panel</h1>
        </Col>
      </Row>
      <Row>
        <Col>
          <TransactionTable
            transactions={transactions}
            onDelete={handleDelete}
            onSearch={handleSearch}
            onDateFilter={handleDateFilter}
            onSort={handleSort}
            onFilterChange={handleFilterChange}
            filters={filters}
          />
        </Col>
      </Row>
    </Container>
  );
};

export default AdminPanel;
