// src/components/TransactionTable.js
import React from "react";
import { Table, Button } from "react-bootstrap";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const TransactionTable = ({
  transactions,
  onDelete,
  onSearch,
  onDateFilter,
  onSort,
  filters,
}) => {
  const sortedTransactions = [...transactions].sort((a, b) => {
    // Sort by date in descending order
    return new Date(b.date) - new Date(a.date);
  });

  const filteredTransactions = sortedTransactions.filter((transaction) => {
    return (
      transaction.id.toString().includes(filters.id) &&
      transaction.amount.toString().includes(filters.amount) &&
      transaction.customer
        .toLowerCase()
        .includes(filters.customer.toLowerCase()) &&
      transaction.status.toLowerCase().includes(filters.status.toLowerCase()) &&
      (filters.startDate
        ? new Date(transaction.date) >= filters.startDate
        : true) &&
      (filters.endDate ? new Date(transaction.date) <= filters.endDate : true)
    );
  });

  return (
    <div>
      <div>
        <label>
          Search by ID:
          <input
            type="text"
            onChange={(e) => onSearch({ id: e.target.value })}
          />
        </label>
      </div>
      <div>
        <label>
          From Date:
          <DatePicker
            selected={filters.startDate}
            onChange={(date) => onDateFilter({ startDate: date })}
          />
        </label>
        <label>
          To Date:
          <DatePicker
            selected={filters.endDate}
            onChange={(date) => onDateFilter({ endDate: date })}
          />
        </label>
        <Button variant="secondary" onClick={() => onSort("asc")}>
          ascending
        </Button>
        <Button variant="secondary" onClick={() => onSort("desc")}>
          descending
        </Button>
      </div>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>ID</th>
            <th>Amount</th>
            <th>Customer</th>
            <th>Status</th>
            <th>Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredTransactions.map((transaction) => (
            <tr key={transaction.id}>
              <td>{transaction.id}</td>
              <td>{transaction.amount}</td>
              <td>{transaction.customer}</td>
              <td>{transaction.status}</td>
              <td>{transaction.date}</td>
              <td>
                <Button
                  variant="danger"
                  onClick={() => onDelete(transaction.id)}
                >
                  Delete
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default TransactionTable;
