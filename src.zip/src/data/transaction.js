// src/data/transactions.js
const transactions = [
    { id: 1, amount: 100, customer: 'John Doe', status: 'approved' },
    { id: 2, amount: 150, customer: 'Jane Smith', status: 'pending' },
    // Add more sample data
  ];
  
  export default transactions;
  