// src/App.js
import React from 'react';
import AdminPanel from './components/AdminPanel';
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS
import './App.css'; // Import your custom styles

function App() {
  return (
    <div className="App">
      <div className="header">
        <h1>Transaction Management System</h1>
      </div>
      <div className="container">
        <AdminPanel />
      </div>
    </div>
  );
}

export default App;
